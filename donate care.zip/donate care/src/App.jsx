import React from 'react';
import './App.css';

function App() {
    return (
        <div className="app">
            <header className="navbar">
                <div className="container">
                    <div className="logo">
                        <span className="logo-blue">Donate</span><span className="logo-green">Care</span>
                    </div>
                    <nav className="nav-links">
                        <a href="#how-it-works">How it Works</a>
                        <a href="#emergency">Emergency</a>
                        <a href="#donors">Donors</a>
                        <a href="#ngos">NGOs</a>
                        <button className="btn btn-outline">Login</button>
                        <button className="btn btn-primary">Sign Up</button>
                    </nav>
                </div>
            </header>

            <section className="hero">
                <div className="container">
                    <div className="hero-content">
                        <h1>Connecting Hearts, <br /><span className="text-highlight">Saving Lives.</span></h1>
                        <p>A unified digital ecosystem for emergency support, blood donation, and transparent NGO contributions.</p>
                        <div className="hero-ctas">
                            <button className="btn btn-primary btn-lg">Donate Now</button>
                            <button className="btn btn-secondary btn-lg">Emergency Support</button>
                        </div>
                    </div>
                    <div className="hero-image">
                        <div className="glass-card impact-card">
                            <h3>Total Impact</h3>
                            <div className="stat">1.2M+</div>
                            <p>Lives Touched</p>
                        </div>
                    </div>
                </div>
            </section>

            <section className="stats-strip">
                <div className="container">
                    <div className="stat-item">
                        <span className="stat-number">500+</span>
                        <span className="stat-label">Partner Hospitals</span>
                    </div>
                    <div className="stat-item">
                        <span className="stat-number">200+</span>
                        <span className="stat-label">Verified NGOs</span>
                    </div>
                    <div className="stat-item">
                        <span className="stat-number">$10M+</span>
                        <span className="stat-label">Donations Raised</span>
                    </div>
                    <div className="stat-item">
                        <span className="stat-number">50k+</span>
                        <span className="stat-label">Active Donors</span>
                    </div>
                </div>
            </section>

            <section id="emergency" className="emergency-feed container">
                <div className="section-header">
                    <span className="badge badge-red">LIVE</span>
                    <h2>Emergency Response Feed</h2>
                    <p>Real-time emergency requests requiring immediate attention.</p>
                </div>
                <div className="feed-grid">
                    {[
                        { id: 1, type: 'Blood Needed', location: 'City Hospital, NY', patient: 'A+ Required', time: '2m ago', urgency: 'High' },
                        { id: 2, type: 'Oxygen Supply', location: 'Grace Care Unit', patient: '5 Cylinders', time: '15m ago', urgency: 'Critical' },
                        { id: 3, type: 'Emergency Funds', location: 'St. Jude Center', patient: '$2,000 Goal', time: '1h ago', urgency: 'Medium' }
                    ].map(item => (
                        <div key={item.id} className="feed-card">
                            <div className="card-top">
                                <span className={`urgency ${item.urgency.toLowerCase()}`}>{item.urgency}</span>
                                <span className="time">{item.time}</span>
                            </div>
                            <h3>{item.type}</h3>
                            <p className="location">📍 {item.location}</p>
                            <p className="detail">{item.patient}</p>
                            <button className="btn btn-outline btn-sm">Help Now</button>
                        </div>
                    ))}
                </div>
            </section>

            <section id="how-it-works" className="features-section">
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Our Global Ecosystem</h2>
                        <p>Empowering every stakeholder in the donation lifecycle.</p>
                    </div>
                    <div className="features-grid">
                        <div className="feature-card">
                            <div className="icon-box icon-blue">👤</div>
                            <h3>For Donors</h3>
                            <p>Track your contributions, find blood donation camps, and donate with 100% transparency.</p>
                            <a href="#" className="learn-more">Get Started →</a>
                        </div>
                        <div className="feature-card">
                            <div className="icon-box icon-green">🏨</div>
                            <h3>For Hospitals</h3>
                            <p>Post real-time requirements for blood, medicine, and emergency supplies instantly.</p>
                            <a href="#" className="learn-more">Partner with Us →</a>
                        </div>
                        <div className="feature-card">
                            <div className="icon-box icon-blue-dark">🤝</div>
                            <h3>For NGOs</h3>
                            <p>Manage fundraising campaigns, social impact reports, and volunteer networks efficiently.</p>
                            <a href="#" className="learn-more">Register NGO →</a>
                        </div>
                    </div>
                </div>
            </section>

            <section className="dashboard-preview">
                <div className="container">
                    <div className="section-header text-center">
                        <h2>Personalized Dashboard</h2>
                        <p>Manage your impact with our intuitive dashboard-style interface.</p>
                    </div>
                    <div className="dashboard-mockup">
                        <div className="mockup-sidebar">
                            <div className="mockup-item active">Overview</div>
                            <div className="mockup-item">Donations</div>
                            <div className="mockup-item">Emergency Alerts</div>
                            <div className="mockup-item">Settings</div>
                        </div>
                        <div className="mockup-content">
                            <div className="mockup-header">
                                <h3>Welcome back, Sarah!</h3>
                                <div className="user-avatar"></div>
                            </div>
                            <div className="mockup-stats">
                                <div className="m-stat">
                                    <span>Total Donated</span>
                                    <strong>$1,250</strong>
                                </div>
                                <div className="m-stat">
                                    <span>Lives Saved</span>
                                    <strong>12</strong>
                                </div>
                                <div className="m-stat">
                                    <span>Active Alerts</span>
                                    <strong>3</strong>
                                </div>
                            </div>
                            <div className="mockup-recent">
                                <h4>Recent Activity</h4>
                                <div className="m-activity">Blood Donation - City Hospital</div>
                                <div className="m-activity">NGO Support - Clean Water Fund</div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <footer className="footer">
                <div className="container">
                    <div className="footer-content">
                        <div className="footer-brand">
                            <div className="logo">
                                <span className="logo-blue">Donate</span><span className="logo-green">Care</span>
                            </div>
                            <p>Making emergency support and donations accessible, digital, and transparent for everyone.</p>
                        </div>
                        <div className="footer-links">
                            <h4>Platform</h4>
                            <a href="#">About Us</a>
                            <a href="#">Emergency Feed</a>
                            <a href="#">Trust & Safety</a>
                        </div>
                        <div className="footer-links">
                            <h4>Support</h4>
                            <a href="#">Contact</a>
                            <a href="#">FAQ</a>
                            <a href="#">Privacy Policy</a>
                        </div>
                    </div>
                    <div className="footer-bottom">
                        <p>&copy; 2026 DonateCare System. All rights reserved.</p>
                    </div>
                </div>
            </footer>
        </div>
    );
}

export default App;
